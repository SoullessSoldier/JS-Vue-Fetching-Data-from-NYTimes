<template>
  <footer
    class="px-4 py-8 text-sm font-bold text-center text-green-100 bg-green-900"
  >
    <p class="text-sm tracking-wide">Copyright (c) 2021 SitePoint</p>
  </footer>
</template>
